import java.util.*;
public class Main {

    public static void main (String[] args){
        while (true){
            System.out.println(getCrashNumber());

        }

    }

    public static double getCrashNumber(){
        Random rand = new Random();
        double H = rand.nextInt((int) (Math.pow(2, 52) - 1));
        return 0.99*(Math.pow(2, 52))/(Math.pow(2, 52)-H);
    }
}
