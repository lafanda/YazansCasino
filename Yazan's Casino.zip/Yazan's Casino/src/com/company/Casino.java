/*
Yazan's Casino
a 4 game casino mad eup of Mine Sweeper, Dice, Crash and BlackJack\
each game is very unique but the one thing that connects them is your balance
you start the game with $1000 each game (other then minesweeper) allows you to bet
giving you an opportunity to build your fortune. if the user is running low on money
they can play mine sweeper, mine sweeper costs $20 to play but if you win you are given
$1000
*/
package com.company;
import javax.swing.*;
public class Casino extends JFrame {
    public Casino() {
        super("Move the Box");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        CasinoPanel game = new CasinoPanel(this);
        add(game);
        pack();
        setVisible(true);
    }
    public static void main(String[] arguments) {
        Casino frame = new Casino();
    }

}
