//not much is done here other then set the hit boxes and load the images for the other games
package com.company;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lobby {
    static Rectangle BlackJack = new Rectangle(150,200,150,150); //image hitboxes so you can chose a game
    static Rectangle MineSweeper = new Rectangle(550,600,150,150);
    static Rectangle Crash = new Rectangle(150,600,150,150);
    static Rectangle Dice = new Rectangle(550,200,150,150);

    static Scanner input = null; //file io

    //draws the lobby
    static  void draw(Graphics g){
        Font font = new Font("Calibre",Font.BOLD, 25);
        Font font2 = new Font("Bernard MT Condensed",Font.BOLD, 80);
        Font font3 = new Font("Calibre",Font.BOLD, 12);
        g.setFont(font);

        Image Dice = new ImageIcon("Dice.jpg").getImage(); //load images
        Image lobby = new ImageIcon("lobby.jpg").getImage();
        Image BlackJack = new ImageIcon("BlackJack.png").getImage();
        Image mineSweeper = new ImageIcon("MineSweeper.jpg").getImage();
        Image crash = new ImageIcon("Crash.jpg").getImage();
        g.drawImage(lobby, 0, 0, null);

        File file = new File("Balance.txt");  //file io
        try {
            input = new Scanner(file); //value of file
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        CasinoPanel.balance = input.nextInt(); //makes your balance the value of the file

        g.setColor(new Color(0x33771C)); //setting colour and drawing balance
        g.drawString("Balance : $"+CasinoPanel.balance,25,50);

        g.drawImage(BlackJack, 150, 200, null); //drawing images for games
        g.drawImage(mineSweeper, 550, 600, null);
        g.drawImage(crash, 150, 600, null);
        g.drawImage(Dice, 550, 200, null);

        g.setFont(font2);
        g.setColor(new Color(0xA70431));
        g.drawString("Yazan's Casino",180,500); //draws title

        g.setFont(font3);
        g.setColor(Color.white);
        g.drawString("Left Click to Play right Click for more info (esc to return to lobby)",10,790); //draws text
        g.drawString("Black Jack",195,190);
        g.drawString("Crash",205,590);
        g.drawString("Dice",610,190);
        g.drawString("Mine Sweeper",585,590);



    }
}
