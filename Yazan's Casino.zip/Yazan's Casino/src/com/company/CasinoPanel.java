/*
minor calculations done here for the sake of simplicity
makes the panels for all the games
all mouse and keyboard actions are done here as well
 */
package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

class CasinoPanel extends JPanel implements KeyListener, ActionListener, MouseListener{
    private Timer myTimer; //frame rate timer
    Timer start = new Timer(2,this); // starts mine sweeper after 0.02 seconds so that clicking on the icon doesnt click in the game
    Timer blackJackStart = new Timer(2000,this); // starts mine sweeper after 0.02 seconds so that clicking on the icon doesnt click in the game
    private boolean [] keys = new boolean[KeyEvent.KEY_LAST +1];
    static int balance = 1000; // starting balance

    int x,y; //x and y of mouse
    int size = 17;
    static boolean tempClick; //used to set something once
    static boolean firstClick = true; // the first click in mine sweeper

    public String Game = "Lobby"; //which game is running

    private MineSweeper mineSweeper; //creating the objects
    public Crash crash = new Crash();
    public Dice dice = new Dice();
    static BlackJack player = new BlackJack(0,0);
    static BlackJack dealer =new BlackJack (1,0);

    Casino main; //used for pack();

    //constructor sets default for  objects
    public CasinoPanel (Casino m){
        main = m;
        setPreferredSize(new Dimension(800, 800));

        MineSweeper.squares = new MineSweeper[size][size]; //creates 288  square objects and sets them an xy
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                mineSweeper = new MineSweeper(false, 0, x,y, false);
                MineSweeper.squares[y][x] = mineSweeper; //adds the objects too an array
                }
            }
        player = new BlackJack(0,0); //player and dealer for black jack
        dealer = new BlackJack(1,0);

        addKeyListener(this);
        addMouseListener(this);
        myTimer = new Timer(50, this);
    }

    @Override
    public void addNotify() {
        super.addNotify();
        setFocusable(true);
        requestFocus();
        myTimer.start();
    }
    //constantly runs
    public void updateGame() {
        Path filePath = Path.of("Balance.txt");
            try {
                Files.writeString(filePath, Integer.toString(balance));
            } catch (IOException e) {
                e.printStackTrace();
            }
        if (Game.equals("Mine Sweeper")) { // sets the first click to true
            if (tempClick) {
                firstClick = true;
                tempClick = false;
            }
        }
        if(Game.equals("BlackJack")){ //calls the function in blackjack that constantly runs
            player.gameLoop();
            if(BlackJack.bust){ // if you bust end the round and restart the game
                BlackJack.tempBet = BlackJack.bet;
                BlackJack.stand = true;
                blackJackStart.start();
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent keyEvent) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()] = true;
        if(keys[KeyEvent.VK_ESCAPE]){ //if you are in a game and press escape it sends you back to the lobby
            switch (Game) {
                case "Mine Sweeper":
                    mineSweeper.reset();
                    Game = "Lobby";
                    break;
                case "BlackJack":
                    dealer.reStart(1);
                    player.reStart(0);
                    Game = "Lobby";

                    break;
                case "Crash":
                    Crash.reset();
                    Game = "Lobby";

                    break;
                default:
                    Game = "Lobby";
                    break;
            }
            setPreferredSize(new Dimension(800, 800));
            main.pack();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()] = false;
    }
    @Override
    public void paint(Graphics g) {
        switch (Game) {
            case "Lobby":
                Lobby.draw(g); // draws the lobby
                setPreferredSize(new Dimension(800, 800)); //set screen size
                setBounds(0,0,800,800);
                main.pack();
                break;
            case "Mine Sweeper":
                setPreferredSize(new Dimension(510, 570));
                setBounds(0,0,510,570);
                main.pack(); // set screen size
                mineSweeper.DrawBoard(g, size); // calls draw methods
                mineSweeper.drawBottom(g);
                if (!firstClick) {
                    for (int i = 0; i < size; i++) { //itterates through the square objects
                        for (int k = 0; k < size; k++) {
                            if (MineSweeper.squares[k][i].revealed) { // draw the number if they are revealed
                                MineSweeper.squares[k][i].DrawSquare(g);
                            }
                            if (MineSweeper.squares[k][i].flag) { //draw the flag if right clicked on
                                MineSweeper.squares[k][i].DrawFlag(g);
                            }
                        }
                    }
                }
                break;
            case "Crash":
                setPreferredSize(new Dimension(600, 700)); //set screen size
                setBounds(0,0,600,700);
                main.pack();

                g.setColor(new Color(0x758139)); //draw the background
                g.fillRect(0, 0, 600, 700);
                crash.Draw(g);
                break;
            case "Dice":
                setPreferredSize(new Dimension(600, 600)); //set screen size
                setBounds(0,0,600,600);
                main.pack();

                g.setColor(new Color(0x758139)); //draw background
                g.fillRect(0, 0, 600, 600);
                dice.draw(g);

                break;
            case "BlackJack":
                setPreferredSize(new Dimension(800, 530)); // sets screen size
                setBounds(0,0,800,530);
                main.pack();

                BlackJack.drawTable(g); //draws the table
                player.drawCards(g);
                dealer.drawCards(g);
                player.drawAnimation(g);
                dealer.drawAnimation(g);
                break;
            case "Mine Sweeper2":
                setPreferredSize(new Dimension(600, 800)); //set screen size
                setBounds(0,0,600,800);
                main.pack();

                Image instructions = new ImageIcon("MineSweeperControlls.png").getImage(); //load instruction page
                g.drawImage(instructions,0,0,null);
                break;
            case "Crash2": //same as above ^
                setPreferredSize(new Dimension(600, 800));
                setBounds(0,0,600,800);
                main.pack();

                Image instructions2 = new ImageIcon("CrashControls.png").getImage();
                g.drawImage(instructions2,0,0,null);
                break;
            case "Dice2":
                setPreferredSize(new Dimension(600, 800));
                setBounds(0,0,600,800);
                main.pack();

                Image instructions3 = new ImageIcon("DiceControls.png").getImage();
                g.drawImage(instructions3,0,0,null);
                break;
            case "BlackJack2":
                setPreferredSize(new Dimension(600, 800));
                setBounds(0,0,600,800);
                main.pack();

                Image instructions4 = new ImageIcon("BlackJackControlls.png").getImage();
                g.drawImage(instructions4,0,0,null);
                break;
        }
    }

    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        x = (mouseEvent.getX()); // gets the xy of where you clicked
        y = (mouseEvent.getY());

        switch (Game) {
            case "Lobby":
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Lobby.BlackJack.contains(x, y)) {
                    Game = "BlackJack"; //sets the game
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Lobby.MineSweeper.contains(x, y)) {
                    start.start(); //calls start in order to launch mine sweeper without clicking in a square
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Lobby.Crash.contains(x, y)) {
                    Game = "Crash";
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Lobby.Dice.contains(x, y)) {
                    Game = "Dice";
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON3 && Lobby.BlackJack.contains(x, y)) {
                    Game = "BlackJack2"; //loads instruction sheet
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON3 && Lobby.MineSweeper.contains(x, y)) {
                    Game = "Mine Sweeper2";
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON3 && Lobby.Crash.contains(x, y)) {
                    Game = "Crash2";
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON3 && Lobby.Dice.contains(x, y)) {
                    Game = "Dice2";
                }
                break;
            case "Mine Sweeper":
                x = x / 30; //devide x and y by 30 so you can get which square you are clicking on
                y = y / 30;

                int allRevealed = 0; // how many squares are reviled
                for (int i = 0; i < size; i++) {
                    for (int k = 0; k < size; k++) {
                        if (MineSweeper.squares[k][i].revealed || MineSweeper.squares[k][i].flag) {
                            allRevealed += 1;
                            if (allRevealed == 288) {
                                mineSweeper.win = true; // if all the pieces are reviled or flagged you win;
                            }
                        }
                    }
                }

                if (firstClick) { // place the bombs and numbers after the first click so that it doesnt put a bomb there
                    mineSweeper.playTime.start();
                    MineSweeper.placingBombs(size, y, x);
                    MineSweeper.check(size);
                    firstClick = false;
                }

                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && y < size) {
                    MineSweeper.squares[y][x].revealed = true; // revile the position of where you clicked

                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON3 && !MineSweeper.squares[y][x].flag && y < size && !MineSweeper.squares[y][x].revealed) {
                    MineSweeper.squares[y][x].flag = true; //flag wjere you right clicked

                } else if (mouseEvent.getButton() == MouseEvent.BUTTON3 && MineSweeper.squares[y][x].flag && y < size) {
                    MineSweeper.squares[y][x].flag = false; //unflag if you right click again
                }
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && MineSweeper.restartRect.contains(x * 30, y * 30)) {
                    mineSweeper.reset(); //if you click the smily face you restart
                }
                break;
            case "Crash":
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.startRect.contains(x, y) && Crash.bet > 0) {
                    Crash.tempBet = Crash.bet; //if you set a bet and press start start the game, temp bet is the bet you made before you pressed start.
                    Crash.start = true;
                    Crash.newRound = true;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.start && Crash.cashOutRect.contains(x, y)) {
                    balance -= Crash.bet; //set the bet and if you press cashOut take your earnings
                    Crash.cashOut = true;
                }

                //setting bet in increments of 5 10 and 100
                else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.bet5.contains(x, y) && balance - 5 > Crash.bet) {
                    Crash.bet += 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.bet10.contains(x, y) && balance - 10 > Crash.bet) {
                    Crash.bet += 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.bet100.contains(x, y) && balance - 100 > Crash.bet) {
                    Crash.bet += 100;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.betn5.contains(x, y) && Crash.bet > 0) {
                    Crash.bet -= 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.betn10.contains(x, y) && Crash.bet > 0) {
                    Crash.bet -= 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Crash.betn100.contains(x, y) && Crash.bet > 0) {
                    Crash.bet -= 100;
                }
                break;

            case "Dice":
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && dice.upRect.contains(x, y) && dice.bet < 100) {
                    dice.numChoice(1); //increase bet number
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && dice.downRect.contains(x, y) && dice.bet > 0) {
                    dice.numChoice(2); //decrease bet number
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && dice.above.contains(x, y)) {
                    dice.col = Color.GREEN; //choose above or bellow
                    dice.col2 = (new Color(0x758139));
                    dice.choice = true;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && dice.below.contains(x, y)) {
                    dice.col2 = Color.GREEN;
                    dice.col = (new Color(0x758139));
                    dice.choice = false;
                }
                //generate the number
                else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && dice.start.contains(x, y) && Dice.moneyBet > 0) {
                    Dice.tempBet = Dice.moneyBet; // set your bet and take your money
                    balance -= (Dice.tempBet);
                    dice.randNum();

                }
                //setting bet
                else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.bet5.contains(x, y) && balance - 5 > Dice.moneyBet) {
                    Dice.moneyBet += 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.bet10.contains(x, y) && balance - 10 > Dice.moneyBet) {
                    Dice.moneyBet += 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.bet100.contains(x, y) && balance - 100 > Dice.moneyBet) {
                    Dice.moneyBet += 100;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.betn5.contains(x, y) && Dice.moneyBet > 0) {
                    Dice.moneyBet -= 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.betn10.contains(x, y) && Dice.moneyBet > 0) {
                    Dice.moneyBet -= 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && Dice.betn100.contains(x, y) && Dice.moneyBet > 0) {
                    Dice.moneyBet -= 100;
                }
                break;
            case "BlackJack":
                if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.hitRect.contains(x, y) && !BlackJack.stand) {
                    BlackJack.hit = true; //give the player an extra card
                    player.hasHit = true;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.standRect.contains(x, y)  ) {
                    BlackJack.stand = true; // reveal the dealers card

                    BlackJack.tempBet = BlackJack.bet;
                    blackJackStart.start();
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.doubleRect.contains(x, y) && !BlackJack.stand) {
                    BlackJack.hit = true; // double your bet and give an extra card
                    player.hasHit = true;
                    BlackJack.stand = true;
                    BlackJack.bet*=2;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.drawRect.contains(x, y) && !BlackJack.draw && BlackJack.bet>0) {
                    balance-= BlackJack.bet;
                    BlackJack.draw = true; // draws new cards and resets the player and dealer8
                    player.reStart(0);
                    dealer.reStart(1);
                }

                //place bets
                else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.bet5.contains(x, y) && balance-5 > BlackJack.bet) {
                     BlackJack.bet += 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.bet10.contains(x, y) && balance-10 > BlackJack.bet) {
                    BlackJack.bet += 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.bet100.contains(x, y) && balance-100 >BlackJack.bet) {
                    BlackJack.bet += 100;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.betn5.contains(x, y) && BlackJack.bet > 0) {
                    BlackJack.bet -= 5;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.betn10.contains(x, y) && BlackJack.bet > 0) {
                    BlackJack.bet -= 10;
                } else if (mouseEvent.getButton() == MouseEvent.BUTTON1 && BlackJack.betn100.contains(x, y) && BlackJack.bet > 0) {
                    BlackJack.bet -= 100;
                }
                break;
        }
    }


    @Override
    public void mouseReleased(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if((actionEvent).getSource() == myTimer) {
            updateGame();
            repaint();
        }
        if((actionEvent).getSource() == start) {
            Game = "Mine Sweeper"; // set game to mine sweeper
            ((Timer) actionEvent.getSource()).stop();
        }
        if((actionEvent).getSource() == blackJackStart) {
            BlackJack.draw = false; //resets everything in preparation for the next round
            BlackJack.bust = false;
            BlackJack.stand = false;
            ((Timer) actionEvent.getSource()).stop();
        }
    }
}
