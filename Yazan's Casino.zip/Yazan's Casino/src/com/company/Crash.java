/*
crash is a luck based game where the user places a bet and watches a multiplier go up. as the multiplier goes up
the chances of crashing go up. if you crash your original bet is gone, but if you cash out instead your money gets
multiplied by the multiplier of when you pulled out.
 */
package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Crash implements ActionListener {
    private Timer updateMultiplier = new Timer(50, this); //moves the ship
    private Timer exponential = new Timer(5000, this); //every few seconds make the ship go faster

    private DecimalFormat df2 = new DecimalFormat("#.##"); //sets the decimal places for the doubles

    static double multiplier = 1.00; //your earnings
    private double numCrash; //the number it crashes at
    static double increase = 0.01; //the amount the multiplier increases by
    double tempMulti; //the multiplier at the place you pulled out

    int E = 10; //max number
    static int  x = 500; //starting position of ship
    static int  y = 5000;
    static int bet; //how much you bet
    static int tempBet; //how much you bet before you started so that you cant change bet mid game

    static boolean shouldGenNums = true; // makes a new number to crash at
    static boolean start; //starts the game
    static boolean cashOut; //pulling out your earnings
    static boolean roundOver; //the ship crashed
    static boolean temp = true; //used to set the tempMultiplier
    static boolean newRound; //start the next round

    static Rectangle startRect = new Rectangle (400,560,150,30); //sets all the rectangle positions
    static Rectangle cashOutRect = new Rectangle (200,560,150,30);
    static Rectangle bet5 = new Rectangle (50,560,70,30);
    static Rectangle bet10 = new Rectangle (140,560,70,30);
    static Rectangle bet100 = new Rectangle (230,560,70,30);
    static Rectangle betn5 = new Rectangle (50,620,70,30);
    static Rectangle betn10 = new Rectangle (140,620,70,30);
    static Rectangle betn100 = new Rectangle (230,620,70,30);

    //draws the game
    public void Draw(Graphics g){
        Font font = new Font("Times New Roman",Font.BOLD, 30); //loads fonts
        Font font1 = new Font("Times New Roman",Font.BOLD, 20);
        Font font2 = new Font("Times New Roman",Font.BOLD, 15);
        Font font3 = new Font("Times New Roman",Font.ITALIC, 50);
        Image Ship = new ImageIcon("SpaceShip1.png").getImage();
        Image Ship1 = new ImageIcon("SpaceShip.png").getImage();

        g.setFont(font1);
        g.setColor(Color.orange); //draw start button
        g.fillRect(startRect.x,startRect.y,startRect.width,startRect.height);

        if (start){
            g.fillRect(cashOutRect.x,cashOutRect.y,cashOutRect.width,cashOutRect.height);
            g.setColor(Color.black);
            g.drawString( "CASH OUT" ,220,580);//draw cash out button
        }
        if(cashOut){
            g.setFont(font);
            if (temp) {
                tempMulti = multiplier; //sets the mutliplier to when you cashed out
                CasinoPanel.balance+= (tempBet*(tempMulti)); //add your earnings to the total
                temp = false;
            }
            g.setColor(new Color(0x006400));
            g.drawString(tempBet+" X"+df2.format(tempMulti),440,630); //displays how much you won

        }
        if(!cashOut && roundOver){ //same as above but for loss
            g.setColor(new Color(0x650011));
            g.drawString("-$"+tempBet,440,630);
            if (temp) {
                CasinoPanel.balance-= tempBet;
                temp = false;
            }
        }
        if(!start){
            g.setColor(new Color(58)); // draws the betting boxes
            g.fillRect(bet5.x,bet5.y,bet5.width,bet5.height);
            g.fillRect(betn5.x,betn5.y,betn5.width,betn5.height);
            g.setColor(new Color(0x650011));
            g.fillRect(bet10.x,bet10.y,bet10.width,bet10.height);
            g.fillRect(betn10.x,betn10.y,betn10.width,betn10.height);
            g.setColor(new Color(0x006400));
            g.fillRect(bet100.x,bet100.y,bet100.width,bet100.height);
            g.fillRect(betn100.x,betn100.y,betn100.width,betn100.height);
            g.setColor(Color.black);

            g.setFont(font2); //drawing the text
            g.drawString(" bet = $"+bet,300,580);
            g.setColor(Color.white);
            g.drawString("bet + $5",60,580);
            g.drawString("bet + $10",140,580);
            g.drawString("bet + $100",230,580);
            g.drawString("bet - $5",60,640);
            g.drawString("bet - $10",140,640);
            g.drawString("bet - $100",230,640);

        }
        g.setFont(font1);
        g.setColor(Color.black);
        g.drawString( "START" ,440,580); //drawing the grid
        g.drawRect(50,50, 1,500);
        g.drawRect(50,550, 500,1);
        g.drawString( "10X" ,10,70);
        g.drawString( "5X" ,10,300);
        g.drawString( "1X" ,10,550);
        g.setFont(font3);
        df2.setRoundingMode(RoundingMode.DOWN);
        g.drawString( "X" + df2.format(multiplier),250,45);

        if (shouldGenNums){ //calls the function that makes the number
            numGen();
        }

        if(y/10 > 450) { //draws the ship and after a bit it makes the ship go more vertical
            g.drawImage(Ship, x / 10, y / 10, null);
        }
        else{
            g.drawImage(Ship1,x/10-22,y/10-20,null);
        }
        if(newRound){ //makes new round
            temp = true;
            cashOut = false;
            newRound = false;
        }

    }
    //generates the random number using the actual formula casinos use
    public void numGen() {
        Random rand = new Random();
        double H = rand.nextInt(10); //formula used by casinos to generate the random number
        numCrash =  ((E*100 - H)/(E-H))/100;
        updateMultiplier.start();
        exponential.start();
        shouldGenNums = false;
    }
    //restarts the game for the next round
    public static void reset(){
        bet = 0; //resets everything
        start = false;
        increase = 0.01;
        multiplier = 1;
        shouldGenNums = true;
        x = 500;
        y = 5000;
    }

    // theres 2 timers
    //one moves the ship  and the other changes the speed that the ship moves at
    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if(start) {
            if ((actionEvent).getSource() == updateMultiplier) {
                if (multiplier < numCrash) { //moves the ship exponentially
                    roundOver = false;
                    x += 8;
                    y -= increase * 500;
                    multiplier += increase;
                }
                if (multiplier >= numCrash) { //ends the level
                    roundOver = true;
                    reset();

                }
            }
            if ((actionEvent).getSource() == exponential) { //speeds up the multiplier
                increase += 0.02;
            }
        }

    }
}

