/*
a game of luck where the user picks a number and decides if the randomly generated number will be higher or lower then
that number. depending on the number you chose the multiplier on your bet will be different.
 */
package com.company;
import java.text.DecimalFormat;
import java.awt.*;
import java.util.Random;

public class Dice  {
    Rectangle upRect = new Rectangle (50,250,50,50); //setting rectangles
    Rectangle downRect =  new Rectangle ( 500,250,50,50);
    Rectangle above = new Rectangle (200,120,220,90);
    Rectangle below = new Rectangle(200,330,220,90);
    Rectangle start = new Rectangle(480,40,100,50);
    static Rectangle bet5 = new Rectangle (50,460,70,30);
    static Rectangle bet10 = new Rectangle (140,460,70,30);
    static Rectangle bet100 = new Rectangle (230,460,70,30);
    static Rectangle betn5 = new Rectangle (50,520,70,30);
    static Rectangle betn10 = new Rectangle (140,520,70,30);
    static Rectangle betn100 = new Rectangle (230,520,70,30);

    public double bet = 50; //the number you chose
    static int moneyBet = 0; //how much your betting
    static int tempBet = 0; // the bet you make before you press start
    static boolean temp = true; //used to add the bet to the balance

    Color col = (new Color(0x758139));; //commonly used colours
    Color col2 = Color.GREEN;

    double multiplier; // the multiplier

    boolean win; //if you won or not
    boolean choice; //higher = true lower = false

    boolean numGenerated = false; //has the random number been generated
    private DecimalFormat df2 = new DecimalFormat("#.##"); //amount of decimal places
    private DecimalFormat df0 = new DecimalFormat("#");

    Random rand = new Random();
    int number = rand.nextInt(101); //generates a random number from 0-100

    public void numChoice(int betUp){
        if(betUp ==1){ //increases the number you chose by 5
            bet+=5;
        }
        if(betUp ==2){
            bet-=5;
        }
    }
    public void draw(Graphics g){
        //drawing all the boxes
        Font font = new Font("Times New Roman",Font.ITALIC,15);
        Font font1 = new Font("Calibre",Font.BOLD, 25);
        Font font2 = new Font("Times New Roman",Font.ITALIC, 50); //loads fonts
        Font font3 = new Font("Calibre",Font.BOLD, 20);

        g.setColor(Color.orange);
        g.fillRect(start.x,start.y,start.width,start.height);

        g.setColor(Color.black);
        g.fillRect(downRect.x,downRect.y,downRect.width,downRect.height);
        g.fillRect(upRect.x,upRect.y,upRect.width,upRect.height);
        g.drawRect(above.x,above.y,above.width,above.height);
        g.drawRect(below.x,below.y,below.width,below.height);

        g.setColor(col);
        g.fillRect(above.x,above.y,above.width,above.height);

        g.setColor(col2);
        g.fillRect(below.x,below.y,below.width,below.height);

        g.setColor(Color.black);
        g.setFont(font2);
        g.drawString( "ABOVE",225 ,180);
        g.drawString( "BELOW",225 ,390);
        g.drawString( "GO",495 ,80);
        g.drawRect(255,220,100,100);

        if (bet!=100) { //drawing the number at different place so that its perfectly centered at 3 digits
            g.drawString(df0.format(bet), 280, 290);
        }
        else{
            g.drawString(df0.format(bet), 265, 290);
        }

        g.setFont(font1);
        g.setColor(Color.white); //drawing the arrows
        g.drawString( "^",69 ,286);

        g.setFont(font3);
        g.drawString( "v",518 ,280);

        g.setColor(new Color(58)); //drawing the betting boxes
        g.fillRect(bet5.x,bet5.y,bet5.width,bet5.height);
        g.fillRect(betn5.x,betn5.y,betn5.width,betn5.height);

        g.setColor(new Color(0x650011));
        g.fillRect(bet10.x,bet10.y,bet10.width,bet10.height);
        g.fillRect(betn10.x,betn10.y,betn10.width,betn10.height);

        g.setColor(new Color(0x006400));
        g.fillRect(bet100.x,bet100.y,bet100.width,bet100.height);
        g.fillRect(betn100.x,betn100.y,betn100.width,betn100.height);

        g.setColor(Color.white);

        g.setFont(font);
        g.drawString("bet + $5",60,480);
        g.drawString("bet + $10",140,480);
        g.drawString("bet + $100",230,480);
        g.drawString("bet - $5",60,540);
        g.drawString("bet - $10",140,540);
        g.drawString("bet - $100",230,540);

        g.setColor(Color.black);
        g.drawString("bet = $"+moneyBet,310,510);

        if (numGenerated) {
            g.drawString(""+number,300,70); //draw the random number
            if (win) {
                g.setColor(new Color(0x006400));
                g.setFont(font2);
                g.drawString(tempBet + " X" + df2.format(multiplier-0.1), 400, 500); //draw the multiplier
                if (temp) {
                    CasinoPanel.balance += (tempBet * (multiplier-0.1)); // add the money
                    temp = false;
                }
            }

            else {
                g.setColor(Color.red);
                g.setFont(font2);
                g.drawString("-"+df2.format( tempBet), 500, 500);
            }
        }
    }
    public void randNum(){
        temp = true;
        number = rand.nextInt(101); //generates the number
        if (choice){ //if you bet above and your right generate your multiplier and make win true
            if (bet<number){
                multiplier = bet/(100-bet);
                win = true;
            }
            if (bet>number){ //if your wrong make win false and show your loss
                win = false;
                multiplier = bet*-1;
            }
        }
        if (!choice){ //same as above ^
            if (bet>number){
                multiplier = (100-bet)/bet;
                win = true;
            }
            if (bet<number){
                win = false;
                multiplier = bet*-1;
            }
        }
        if(multiplier == 1){ //make the multiplier faie
            multiplier = 2;
        }
        if(multiplier<1){
            multiplier+=1;
        }
        numGenerated = true;
    }
}
