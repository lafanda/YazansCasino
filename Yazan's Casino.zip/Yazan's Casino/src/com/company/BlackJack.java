/*
the clasic BlackJack
both the dealer and the player are given 2 cards. each card is assigned a value from 1-10
the player can stand draw and double
once the player stands the dealer reveals his hand and however is closest to 21 without going over wins
the dealer can also hit
if the player goes over 21 the round ends
*/
package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.ArrayList;

public class BlackJack implements ActionListener {
    static Image[] cardImages = new Image[52]; //holds all the card images
    int type; //if its the user or dealer
    int handValue; // how much your hand is worth
    static int bet; //how much your betting
    static int tempBet; //your bet when yuo press stand

    static boolean temp = true; //used to add the money
    static boolean win; // if you won or not
    static boolean hit; //if you hit or not
    static boolean bust; //if you busted or not
    static boolean stand; //if you folded or not
    static boolean draw; //start the game
    boolean hasHit; //has the player hit this game

    static Rectangle hitRect = new Rectangle(230, 480, 80, 30); //all the rectangles
    static Rectangle standRect = new Rectangle(340, 480, 120, 30);
    static Rectangle doubleRect = new Rectangle(490, 480, 130, 30);
    static Rectangle bet5 = new Rectangle (10,40,70,30);
    static Rectangle bet10 = new Rectangle (90,40,70,30);
    static Rectangle bet100 = new Rectangle (170,40,70,30);
    static Rectangle betn5 = new Rectangle (10,90,70,30);
    static Rectangle betn10 = new Rectangle (90,90,70,30);
    static Rectangle betn100 = new Rectangle  (170,90,70,30);
    static Rectangle drawRect = new Rectangle (600,220,120,50);

    static Image back = new ImageIcon("BlackJack/back.png").getImage();
    ArrayList<Integer> cards = new ArrayList<>(); //your hand

    Random rand = new Random(); // random

    static Font font = new Font("Times New Roman", Font.BOLD, 15);
    static Font font2 = new Font("Times New Roman",Font.BOLD, 30); //loads fonts

    Timer drawTime = new Timer(300,this); //gives you a new card

    //constructor
    public BlackJack(int Type, int value) {
        handValue = value; //set handvalue and type
        type = Type;

        for (int i = 0; i < 2; i++) { //deals 2 random cards
            int card = rand.nextInt(52) + 1;
            cards.add(card);
            value(card);
        }
    }

    //constatntly running
    public void gameLoop() {
        if (stand) { //if you stand let the dealer count up his total
            CasinoPanel.dealer.total();
        }
        if (hit) { //if you hit give the player a new card and count up his new total
            total();
        }

    }

    //decides who won
    public void total() {
        if (type == 1 && handValue < 16 && stand && !bust|| type == 0 && hit) { //if the dealer can hit or you chose to hit
            drawTime.start(); //draw a card
        }

        if (stand) {
            if (CasinoPanel.dealer.handValue > 21) { // if the dealers hand is over 21 you win
                win = true;
            }
            if (CasinoPanel.dealer.handValue  == 21) { //if the dealers hand is 21 you lose
                win = false;
            }
            if (CasinoPanel.player.handValue > 21) { //if your hand is over 21 you lose
                win = false;
            }
            if (CasinoPanel.player.handValue == 21) { //if your hand is 21 you win
                win = true;
            }
            if(CasinoPanel.player.handValue>CasinoPanel.dealer.handValue && CasinoPanel.player.handValue<=21){
                win = true;//if your hand is larger then the dealers hand you win
            }
            if(CasinoPanel.player.handValue<CasinoPanel.dealer.handValue && CasinoPanel.dealer.handValue<22){
                win = false;//if the dealers hand is larger then your hand you lose
            }
        }
    }
    //calculates the total of your hand
    public void value(int card) {
        if (card % 13 == 1) { //makes the ace either a 1 or 10 depending on whats better for you
            if (handValue + 10 < 22) {
                handValue += 10;
            } else {
                handValue += 1;
            }
        }
        if (card % 13 >= 2 && card % 13 <= 10) { //if you get a 2-10 the value is the same as the number
            handValue += (card % 13);
        }
        if (card % 13 == 11 || card % 13 == 12 || card % 13 == 0) { //jack queen and king are all 10's
            handValue += 10;
        }
        if (cards.size() == 2) { //once you have 2 cards call total
            total();
        }
        if (handValue < 16) { //if the dealers hand is less then 16 call total
            total();
        }
        if(type == 0 && handValue>21){ //if your hand is over 21 you bust
            bust = true;
        }

    }


    public static void drawTable(Graphics g) {
        Image table = new ImageIcon("table.jpg").getImage(); //draw the table
        g.drawImage(table, 0, 0, null);

        g.setColor(new Color(58)); //drawing the betting buttons
        g.fillRect(bet5.x,bet5.y,bet5.width,bet5.height);
        g.fillRect(betn5.x,betn5.y,betn5.width,betn5.height);

        g.setColor(new Color(0x650011));
        g.fillRect(bet10.x,bet10.y,bet10.width,bet10.height);
        g.fillRect(betn10.x,betn10.y,betn10.width,betn10.height);

        g.setColor(new Color(0x006400));
        g.fillRect(bet100.x,bet100.y,bet100.width,bet100.height);
        g.fillRect(betn100.x,betn100.y,betn100.width,betn100.height);

        g.setColor(new Color(0xF2F7E0)); //writing the betting text
        g.setFont(font);
        g.drawString("+ $5",bet5.x+15,bet5.y+20);
        g.drawString("+ $10",bet10.x+15,bet10.y+20);
        g.drawString("+ $100",bet100.x+15,bet100.y+20);
        g.drawString("- $5",betn5.x+15,betn5.y+20);
        g.drawString("- $10",betn10.x+15,betn10.y+20);
        g.drawString("- $100",betn100.x+15,betn100.y+20);

        g.setFont(font2); //draw all the action buttons
        g.setColor(Color.RED);
        g.drawRect(hitRect.x, hitRect.y, hitRect.width, hitRect.height);
        g.drawString("HIT",hitRect.x+20,hitRect.y+25);

        g.setColor(Color.blue);
        g.drawRect(standRect.x, standRect.y, standRect.width, standRect.height);
        g.drawString("STAND",standRect.x+10,standRect.y+25);

        g.setColor(Color.green);
        g.drawRect(doubleRect.x, doubleRect.y, doubleRect.width, doubleRect.height);
        g.drawString("DOUBLE",doubleRect.x,doubleRect.y+25);

        g.setFont(font2);
        g.setColor(Color.black);
        g.drawRect(drawRect.x,drawRect.y,drawRect.width,drawRect.height);
        g.setColor(Color.white);
        g.drawString("Draw",drawRect.x+25,drawRect.y+35);
        g.setFont(font);
        g.drawString("BET: $"+bet,50,500); //display your bet

        for(int i = 0; i<53; i++){ //draw the stack of cards which is actually 1 card drawn 52 times
            g.drawImage(back,50-(i/2),220,null);
        }

    }

    //displays cards
    public void drawCards(Graphics g) {
        if (draw) {
            g.setFont(font);
            for (int i = 1; i < 53; i++) {
                Image cardImage = new ImageIcon(String.format("BlackJack/%.2s.png", i)).getImage();
                cardImages[i - 1] = cardImage; //load all the cards
            }

            if (type == 1) { //draw the dealers cards
                int counter = 0;
                for (int i : cards) {
                    g.drawImage(cardImages[i-1], 300 + (counter), 50, null);
                    if (!stand) { //if you havnt folded yet display one of the cards upside down
                        g.drawImage(back, 350, 50, null);
                    }
                    counter += 50;
                }
                if(stand) { //if you do stand display the dealers handvalue
                    g.setColor(Color.white);
                    g.drawString("" + handValue, 360, 220);
                }
            }
            if (type == 0) { //smae as above bu tfor the player
                int counter = 0;
                for (int i : cards) {
                    g.drawImage(cardImages[i-1], 300 + (counter), 300, null);
                    counter += 50;
                }
                g.setColor(Color.white);
                g.drawString(""+handValue,360,280);
            }
        }
    }
    //displays everything after you stand
    public void drawAnimation(Graphics g) {
        Color col1 = Color.red;
        Color col2 = Color.green;
        g.setFont(font);

        if(CasinoPanel.dealer.handValue >=16 && stand || CasinoPanel.player.handValue>21) { //if the round is over

            if (CasinoPanel.player.handValue == CasinoPanel.dealer.handValue && stand) { //if the player and dealers hands are the same
                g.setColor(Color.white);
                g.setFont(font);
                g.drawString("DRAW", 350, 250);
                if(temp) {
                    CasinoPanel.balance += (tempBet);
                    temp = false;
                }

            } else if (!win && type == 0 && this.handValue > 21) { // if you go over 21
                g.setColor(col1);
                g.setFont(font);
                g.drawString("BUST", 350, 250);
                g.setFont(font2);
                g.drawString("Balance -"+tempBet,50,450);

            } else if (!win) { //if they have a bigger hand
                g.setColor(col1);
                g.setFont(font);
                g.drawString("LOST", 350, 250);
                g.setFont(font2);
                g.drawString("Balance -"+tempBet,50,450);

            } else if (type == 0 && this.handValue == 21 && !hasHit) { //if you have a blackJack
                g.setColor(col2);
                g.setFont(font);
                g.drawString("Black Jack", 350, 250);
                g.setFont(font2);
                g.drawString("Balance +="+(tempBet*2.25),50,450);
                if(temp) {
                    CasinoPanel.balance += (tempBet * 2);
                    temp = false;
                }
            } else { //else you win
                g.setColor(col2);
                g.setFont(font);
                g.drawString("WIN", 350, 250);
                g.setFont(font2);
                g.drawString("Balance +="+(tempBet*2),50,450);
                if (temp) {
                    CasinoPanel.balance += (tempBet * 2);
                    temp = false;
                }

            }
        }
    }
    //gives new cards
    public void reStart(int Type) {
        handValue = 0; //resets all variables and deals 2 cards to each player
        type = Type;
        cards.clear();
        stand = false;
        for (int i = 0; i < 2; i++) {
            int card = rand.nextInt(52) + 1;
            cards.add(card);
            value(card);
        }
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (CasinoPanel.player.handValue <= 21) {
            int card = rand.nextInt(52) + 1;
            cards.add(card); //if you bust reset everything
            bust = false;
            hit = false;
            temp = true;
            value(card);
        }
        ((Timer) actionEvent.getSource()).stop();
    }
}



